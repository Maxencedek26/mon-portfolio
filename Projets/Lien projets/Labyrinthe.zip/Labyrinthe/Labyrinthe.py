"""
labyrinth_complete.py

Features:
- Iterative DFS maze with rooms + extra loops (no recursion limit issues)
- Smooth player movement (Z Q S D)
- Player light (raycast), walls block light
- Basic & Fast enemies:
    * Basic: wander, LOS chase, search last seen, A* fallback
    * Fast: same but faster; must be in player's light for 1.0s before slowing
- Enemies avoid walls (steering) and have anti-stuck kick
- Enemy spawn depends on S, random placement but not near player spawn
- Scrolling camera (800x800) + fullscreen toggle (F)
"""

import pygame
import random
import math
import heapq
import time
import sys

# --------------------------
# CONFIG
# --------------------------
# Maze size (tiles). Must be between 20 and 100 — you can change this.
S = 80

# Enforce bounds
if S < 20: S = 20
if S > 100: S = 100

TILE = 15                   # pixels per tile
WIN_W, WIN_H = 800, 800
FPS = 60

# Light
LIGHT_RADIUS = 10           # tiles visible from player
RAY_COUNT = 200             # rays for player's light (reduced for performance)
RAY_STEP = 0.22

# Enemy scaling with S (you can tweak these multipliers)
BASIC_PER_25_TILES = 2.0    # baseline: approx S/25 basic enemies
FAST_PER_50_TILES = 1.0     # baseline: approx S/50 fast enemies

# Derived counts
NUM_BASIC = max(2, int(round((S / 25.0) * BASIC_PER_25_TILES)))
NUM_FAST = max(1, int(round((S / 50.0) * FAST_PER_50_TILES)))

# Enemy behavior tuning
SEARCH_SECONDS = 3.5
SEARCH_FRAMES = int(SEARCH_SECONDS * FPS)
PATHFIND_COOLDOWN = 0.7     # seconds between A* requests per enemy
MAX_PATH_LEN = 2000

# Fast enemy light exposure required to slow (seconds)
FAST_SLOW_EXPOSURE_SECS = 1.0
FAST_SLOW_EXPOSURE_FRAMES = int(FAST_SLOW_EXPOSURE_SECS * FPS)

# Player movement (tiles / second)
PLAYER_MAX_SPEED = 4.2
PLAYER_ACCEL = 45.0
PLAYER_FRICTION = 12.0

# Anti-stuck
ANTISTUCK_THRESHOLD = 0.0006
ANTISTUCK_SECONDS = 0.45

# Random seed: set to int for reproducible runs, or None for random
RANDOM_SEED = None

# Colors
COLOR_DARK = (8, 8, 8)
COLOR_SEEN_WALL = (85, 85, 85)
COLOR_SEEN_FLOOR = (210, 210, 210)
COLOR_PLAYER = (220, 30, 30)
COLOR_EXIT = (30, 200, 60)
COLOR_BASIC = (190, 80, 80)
COLOR_FAST = (240, 140, 40)
COLOR_HUD = (230, 230, 230)

# Minimum spawn distance from player (in tiles)
SPAWN_MIN_DIST = max(6, S // 8)

# --------------------------
# UTIL: A* pathfinding (lightweight)
# --------------------------
def astar(maze, start, goal, max_nodes=20000):
    w = len(maze[0])
    h = len(maze)
    sx, sy = start
    gx, gy = goal
    if start == goal:
        return [start]
    if not (0 <= gx < w and 0 <= gy < h and maze[gy][gx] == 0):
        return None

    def hcost(a, b):
        return abs(a[0]-b[0]) + abs(a[1]-b[1])

    open_heap = []
    heapq.heappush(open_heap, (hcost(start, goal), 0, start))
    came_from = {start: None}
    gscore = {start: 0}
    explored = 0

    while open_heap and explored < max_nodes:
        _, gcur, current = heapq.heappop(open_heap)
        explored += 1
        if current == goal:
            path = []
            node = current
            while node is not None:
                path.append(node)
                node = came_from[node]
            path.reverse()
            return path
        cx, cy = current
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
            nx, ny = cx+dx, cy+dy
            if not (0 <= nx < w and 0 <= ny < h): continue
            if maze[ny][nx] == 1: continue
            neigh = (nx, ny)
            tentative = gcur + 1
            if neigh not in gscore or tentative < gscore[neigh]:
                gscore[neigh] = tentative
                heapq.heappush(open_heap, (tentative + hcost(neigh, goal), tentative, neigh))
                came_from[neigh] = current
    return None

def smooth_path(maze, path):
    if not path or len(path) <= 2:
        return path
    def clear(a, b):
        (x0,y0),(x1,y1) = a,b
        dx = x1 - x0; dy = y1 - y0
        dist = math.hypot(dx, dy)
        steps = max(1, int(dist / 0.2))
        sx = x0 + 0.5; sy = y0 + 0.5
        sx_step = dx / steps; sy_step = dy / steps
        for _ in range(steps):
            sx += sx_step; sy += sy_step
            tx = int(sx); ty = int(sy)
            if tx < 0 or ty < 0 or ty >= len(maze) or tx >= len(maze[0]): return False
            if maze[ty][tx] == 1: return False
        return True
    new_path = [path[0]]
    i = 0
    while i < len(path)-1:
        j = len(path)-1
        while j > i+1:
            if clear(path[i], path[j]): break
            j -= 1
        new_path.append(path[j])
        i = j
    return new_path

# --------------------------
# Maze generation (iterative DFS + rooms + loops)
# --------------------------
def generate_maze(w, h, rooms_min=3, rooms_max=8):
    maze = [[1 for _ in range(w)] for _ in range(h)]

    # carve rooms
    def carve_rooms():
        num_rooms = random.randint(rooms_min, rooms_max)
        for _ in range(num_rooms):
            rw = random.randint(3, max(3, w // 8))
            rh = random.randint(3, max(3, h // 8))
            rx = random.randint(1, max(1, w - rw - 2))
            ry = random.randint(1, max(1, h - rh - 2))
            for yy in range(ry, ry+rh):
                for xx in range(rx, rx+rw):
                    maze[yy][xx] = 0

    carve_rooms()

    # iterative DFS on odd tiles
    def neighbors(cx, cy):
        dirs = [(2,0),(-2,0),(0,2),(0,-2)]
        random.shuffle(dirs)
        for dx, dy in dirs:
            nx, ny = cx+dx, cy+dy
            if 0 <= nx < w and 0 <= ny < h:
                yield nx, ny, cx + dx//2, cy + dy//2

    # find start inside room if possible
    def find_start():
        for _ in range(1500):
            sx = random.randrange(1, w, 2)
            sy = random.randrange(1, h, 2)
            if maze[sy][sx] == 0:
                return sx, sy
        return random.randrange(1, w, 2), random.randrange(1, h, 2)

    sx, sy = find_start()

    stack = [(sx, sy)]
    maze[sy][sx] = 0
    while stack:
        x, y = stack[-1]
        unvisited = []
        for nx, ny, mx, my in neighbors(x,y):
            if maze[ny][nx] == 1:
                unvisited.append((nx, ny, mx, my))
        if unvisited:
            nx, ny, mx, my = random.choice(unvisited)
            maze[my][mx] = 0
            maze[ny][nx] = 0
            stack.append((nx, ny))
        else:
            stack.pop()

    # add extra passages (loops)
    extra = (w*h) // 18
    for _ in range(extra):
        ax = random.randint(1, w-2)
        ay = random.randint(1, h-2)
        maze[ay][ax] = 0

    return maze, (sx, sy)

# --------------------------
# Visibility: player light via raycast (optimized)
# --------------------------
def compute_visibility(maze, px, py, radius, ray_count, step):
    h = len(maze); w = len(maze[0])
    visible = set()
    visible.add((px, py))
    for i in range(ray_count):
        angle = (i / ray_count) * 2 * math.pi
        dx = math.cos(angle); dy = math.sin(angle)
        x = px + 0.5; y = py + 0.5
        max_steps = int(radius / step) + 2
        for _ in range(max_steps):
            x += dx * step; y += dy * step
            tx = int(x); ty = int(y)
            if tx < 0 or tx >= w or ty < 0 or ty >= h: break
            visible.add((tx, ty))
            if maze[ty][tx] == 1: break
            if math.hypot(tx - px, ty - py) > radius: break
    return visible

# --------------------------
# Enemy classes (with anti-stuck and wall avoidance)
# --------------------------
class Enemy:
    def __init__(self, tx, ty, speed=1.6, vision_range=10, vision_angle=50):
        # position in tile coords (center)
        self.x = tx + 0.5
        self.y = ty + 0.5
        self.vx = 0.0
        self.vy = 0.0
        self.base_speed = speed     # tiles per second
        self.speed = speed
        self.vision_range = vision_range
        self.vision_angle = vision_angle
        self.dir = random.random() * 2 * math.pi
        self.state = "wander"       # wander, chase, search
        # wander target (float center coords)
        self.wander_target = None
        # search fields
        self.last_seen = None
        self.search_timer = 0
        # pathfinding cache
        self.path = None
        self.path_idx = 0
        self.last_path_time = -9999.0
        # anti-stuck
        self.last_pos = (self.x, self.y)
        self.stuck_timer = 0.0

    def tile_pos(self):
        return int(self.x), int(self.y)

    def pick_wander_target(self, maze):
        w = len(maze[0]); h = len(maze)
        for _ in range(40):
            rx = int(self.x) + random.randint(-10, 10)
            ry = int(self.y) + random.randint(-10, 10)
            if 1 <= rx < w-1 and 1 <= ry < h-1 and maze[ry][rx] == 0:
                self.wander_target = (rx + 0.5, ry + 0.5)
                return
        self.wander_target = (self.x, self.y)

    def wander(self, dt, maze):
        if self.wander_target is None or random.random() < 0.006:
            self.pick_wander_target(maze)
        tx, ty = self.wander_target
        dx = tx - self.x; dy = ty - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.35:
            self.wander_target = None
            self.vx = self.vy = 0.0
        else:
            ang = math.atan2(dy, dx); self.dir = ang
            speed = self.speed
            self.vx = math.cos(ang) * speed * dt
            self.vy = math.sin(ang) * speed * dt

    def sees_player(self, ptx, pty, maze):
        dx = (ptx + 0.5) - self.x
        dy = (pty + 0.5) - self.y
        dist = math.hypot(dx, dy)
        if dist > self.vision_range: return False
        ang_to = math.atan2(dy, dx)
        diff = (ang_to - self.dir + math.pi) % (2*math.pi) - math.pi
        if abs(diff) > math.radians(self.vision_angle): return False
        # raycast toward player
        steps = max(4, int(dist / 0.2))
        sx = self.x; sy = self.y
        step_x = dx / steps; step_y = dy / steps
        for _ in range(steps):
            sx += step_x; sy += step_y
            tx = int(sx); ty = int(sy)
            if tx < 0 or ty < 0 or ty >= len(maze) or tx >= len(maze[0]): return False
            if maze[ty][tx] == 1: return False
        return True

    def request_path(self, target_tile, maze):
        now = time.time()
        if now - self.last_path_time < PATHFIND_COOLDOWN:
            return False
        self.last_path_time = now
        start = (int(self.x), int(self.y))
        path = astar(maze, start, target_tile, max_nodes=15000)
        if path:
            path = smooth_path(maze, path)
            if len(path) > MAX_PATH_LEN:
                path = path[:MAX_PATH_LEN]
            self.path = path
            self.path_idx = 0
            return True
        else:
            self.path = None
            return False

    def follow_path(self, dt):
        if not self.path or self.path_idx >= len(self.path):
            self.vx = self.vy = 0.0
            return
        tx, ty = self.path[self.path_idx]
        tgtx = tx + 0.5; tgty = ty + 0.5
        dx = tgtx - self.x; dy = tgty - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.25:
            self.path_idx += 1
            self.vx = self.vy = 0.0
            return
        ang = math.atan2(dy, dx); self.dir = ang
        self.vx = math.cos(ang) * self.speed * dt
        self.vy = math.sin(ang) * self.speed * dt

    def chase(self, ppos, pvel, maze, dt):
        px, py = ppos
        dx = (px + 0.5) - self.x
        dy = (py + 0.5) - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.0001:
            self.vx = self.vy = 0.0; return
        # predictive point
        predict_time = 0.35
        predx = px + pvel[0] * predict_time
        predy = py + pvel[1] * predict_time
        # check LOS to predicted point
        steps = max(4, int(dist / 0.2))
        sx = self.x; sy = self.y
        step_x = (predx + 0.5 - self.x) / max(1, steps)
        step_y = (predy + 0.5 - self.y) / max(1, steps)
        blocked = False
        for _ in range(steps):
            sx += step_x; sy += step_y
            tx = int(sx); ty = int(sy)
            if tx < 0 or ty < 0 or ty >= len(maze) or tx >= len(maze[0]):
                blocked = True; break
            if maze[ty][tx] == 1:
                blocked = True; break
        if not blocked:
            ang = math.atan2((predy+0.5)-self.y, (predx+0.5)-self.x)
            self.dir = ang
            self.vx = math.cos(ang) * self.speed * dt
            self.vy = math.sin(ang) * self.speed * dt
            self.path = None
        else:
            target_tile = (int(px), int(py))
            if self.path is None or self.path_idx >= len(self.path):
                self.request_path(target_tile, maze)
            if self.path:
                self.follow_path(dt)
            else:
                # small rotate/wander
                self.vx = self.vy = 0.0
                self.dir += 0.04
                if random.random() < 0.02:
                    self.dir += random.uniform(-0.7, 0.7)

    def start_searching(self, px, py, maze):
        self.last_seen = (px + 0.5, py + 0.5)
        self.search_timer = SEARCH_FRAMES
        # attempt path to last seen tile
        tile = (int(px), int(py))
        self.request_path(tile, maze)

    def search_behavior(self, dt, maze):
        if self.last_seen is None:
            self.state = "wander"; return
        if self.path:
            self.follow_path(dt); return
        lx, ly = self.last_seen
        dx = lx - self.x; dy = ly - self.y
        dist = math.hypot(dx, dy)
        if dist > 0.4:
            ang = math.atan2(dy, dx); self.dir = ang
            self.vx = math.cos(ang) * self.speed * dt
            self.vy = math.sin(ang) * self.speed * dt
        else:
            self.vx = self.vy = 0.0
            self.dir = (self.dir + 0.05) % (2*math.pi)
            self.search_timer -= 1
            if self.search_timer <= 0:
                self.state = "wander"
                self.last_seen = None
                self.path = None

    def anti_stuck(self, dt):
        moved = (self.x - self.last_pos[0])**2 + (self.y - self.last_pos[1])**2
        if moved < ANTISTUCK_THRESHOLD:
            self.stuck_timer += dt
        else:
            self.stuck_timer = 0.0
        self.last_pos = (self.x, self.y)
        if self.stuck_timer > ANTISTUCK_SECONDS:
            angle = random.random() * 2 * math.pi
            force = 0.9
            # small kick
            self.vx += math.cos(angle) * force
            self.vy += math.sin(angle) * force
            self.stuck_timer = 0.0

class FastEnemy(Enemy):
    def __init__(self, tx, ty):
        super().__init__(tx, ty, speed=3.6, vision_range=18, vision_angle=80)
        self.slow_speed = 1.05
        # exposure frames inside player's light
        self.light_exposure = 0

    def adjust_speed(self, player_tile_x, player_tile_y, vis_tiles):
        if (int(self.x), int(self.y)) in vis_tiles:
            self.light_exposure += 1
        else:
            self.light_exposure = 0
        if self.light_exposure >= FAST_SLOW_EXPOSURE_FRAMES:
            self.speed = self.slow_speed
        else:
            self.speed = self.base_speed

# --------------------------
# Movement collision helpers
# --------------------------
def move_entity_with_collision(ent, maze):
    w = len(maze[0]); h = len(maze)
    # move X
    nx = ent.x + ent.vx
    ny = ent.y
    tx = int(nx); ty = int(ny)
    if 0 <= tx < w and 0 <= ty < h and maze[ty][tx] == 0:
        ent.x = nx
    else:
        ent.vx = 0.0
    # move Y
    nx = ent.x
    ny = ent.y + ent.vy
    tx = int(nx); ty = int(ny)
    if 0 <= tx < w and 0 <= ty < h and maze[ty][tx] == 0:
        ent.y = ny
    else:
        ent.vy = 0.0

# Wall avoidance steering
def steer_away_from_walls(ent, maze, strength=0.18):
    tx, ty = int(ent.x), int(ent.y)
    # directions
    checks = [(0,-1),(0,1),(-1,0),(1,0), (-1,-1),(1,-1),(-1,1),(1,1)]
    for dx, dy in checks:
        nx = tx + dx; ny = ty + dy
        blocked = False
        if nx < 0 or nx >= len(maze[0]) or ny < 0 or ny >= len(maze):
            blocked = True
        else:
            if maze[ny][nx] == 1: blocked = True
        if blocked:
            ent.vx += -dx * strength
            ent.vy += -dy * strength

# --------------------------
# Camera helpers
# --------------------------
def world_to_screen(wx, wy, cam_x, cam_y):
    sx = wx * TILE - cam_x
    sy = wy * TILE - cam_y
    return int(sx), int(sy)

# --------------------------
# Main game
# --------------------------
def main():
    if RANDOM_SEED is not None:
        random.seed(RANDOM_SEED)
    pygame.init()
    screen = pygame.display.set_mode((WIN_W, WIN_H))
    pygame.display.set_caption("Labyrinth — Improved Enemies & Smooth Movement")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 20)

    # precompute tile/frame conversion
    tile_per_frame = 1.0 / FPS
    player_max_speed_tpf = PLAYER_MAX_SPEED * tile_per_frame
    player_acc_tpf = PLAYER_ACCEL * tile_per_frame
    player_fric_tpf = PLAYER_FRICTION * tile_per_frame

    # generate maze
    maze, start_tile = generate_maze(S, S, rooms_min=max(3, S//30), rooms_max=max(4, S//12))
    start_x, start_y = start_tile

    # pick exit on boundary
    boundary = []
    for i in range(S):
        if maze[0][i] == 0: boundary.append((i, 0))
        if maze[S-1][i] == 0: boundary.append((i, S-1))
        if maze[i][0] == 0: boundary.append((0, i))
        if maze[i][S-1] == 0: boundary.append((S-1, i))
    exit_tile = random.choice(boundary) if boundary else (1,0)

    # player floats (center coords)
    player_x = start_x + 0.5
    player_y = start_y + 0.5
    player_vx = 0.0
    player_vy = 0.0

    # spawn enemies (A) randomly but not near player spawn
    enemies = []
    spawn_attempts = 0
    total_needed = NUM_BASIC + NUM_FAST
    # preferred spawn tiles list
    floor_tiles = [(x,y) for y in range(1,S-1) for x in range(1,S-1) if maze[y][x] == 0]
    random.shuffle(floor_tiles)
    for (tx,ty) in floor_tiles:
        if len(enemies) >= total_needed: break
        # don't spawn at start or exit
        if (tx,ty) == (start_x, start_y) or (tx,ty) == exit_tile: continue
        # ensure minimum distance from start
        if math.hypot(tx - start_x, ty - start_y) < SPAWN_MIN_DIST: continue
        # accept tile
        if len(enemies) < NUM_BASIC:
            enemies.append(Enemy(tx, ty, speed=1.6, vision_range=10, vision_angle=50))
        else:
            enemies.append(FastEnemy(tx, ty))
    # fallback: if not enough spawned, fill random places ignoring distance
    while len(enemies) < total_needed:
        ex = random.randint(1, S-2); ey = random.randint(1, S-2)
        if maze[ey][ex] == 0 and (ex,ey) != (start_x,start_y) and (ex,ey) != exit_tile:
            if len(enemies) < NUM_BASIC:
                enemies.append(Enemy(ex, ey, speed=1.6, vision_range=10, vision_angle=50))
            else:
                enemies.append(FastEnemy(ex, ey))

    cam_x = 0.0; cam_y = 0.0
    fullscreen = False
    last_time = time.time()
    running = True

    while running:
        now = time.time()
        dt_seconds = now - last_time
        last_time = now
        dt_seconds = min(0.05, dt_seconds)
        dt_frames = dt_seconds * FPS

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    running = False
                elif ev.key == pygame.K_f:
                    fullscreen = not fullscreen
                    if fullscreen:
                        screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
                    else:
                        screen = pygame.display.set_mode((WIN_W, WIN_H))

        # --- player input (smooth) ZQSD ---
        keys = pygame.key.get_pressed()
        move_x = 0.0; move_y = 0.0
        if keys[pygame.K_z]: move_y -= 1.0
        if keys[pygame.K_s]: move_y += 1.0
        if keys[pygame.K_q]: move_x -= 1.0
        if keys[pygame.K_d]: move_x += 1.0

        # diagonal normalize
        if move_x != 0 and move_y != 0:
            inv = 1.0 / math.sqrt(2.0)
            move_x *= inv; move_y *= inv

        # accelerate (tiles/frame)
        player_vx += move_x * player_acc_tpf * dt_frames
        player_vy += move_y * player_acc_tpf * dt_frames

        # friction
        if move_x == 0:
            if player_vx > 0: player_vx = max(0, player_vx - player_fric_tpf * dt_frames)
            elif player_vx < 0: player_vx = min(0, player_vx + player_fric_tpf * dt_frames)
        if move_y == 0:
            if player_vy > 0: player_vy = max(0, player_vy - player_fric_tpf * dt_frames)
            elif player_vy < 0: player_vy = min(0, player_vy + player_fric_tpf * dt_frames)

        # clamp speed
        speed_now = math.hypot(player_vx, player_vy)
        max_sp = player_max_speed_tpf = PLAYER_MAX_SPEED * (1.0 / FPS)
        if speed_now > max_sp:
            f = max_sp / speed_now
            player_vx *= f; player_vy *= f

        # move player with collision (use tmp object)
        class Tmp: pass
        ptmp = Tmp()
        ptmp.x = player_x; ptmp.y = player_y; ptmp.vx = player_vx; ptmp.vy = player_vy
        move_entity_with_collision(ptmp, maze)
        player_x = ptmp.x; player_y = ptmp.y; player_vx = ptmp.vx; player_vy = ptmp.vy

        # integer tile coords
        player_tile_x = int(player_x)
        player_tile_y = int(player_y)

        # visibility
        vis_tiles = compute_visibility(maze, player_tile_x, player_tile_y, LIGHT_RADIUS, RAY_COUNT, RAY_STEP)

        # enemy updates
        for enemy in enemies:
            # fast enemy exposure -> adjust speed
            if isinstance(enemy, FastEnemy):
                enemy.adjust_speed(player_tile_x, player_tile_y, vis_tiles)

            # detection: if sees player -> chase and start search (records last_seen)
            if enemy.sees_player(player_tile_x, player_tile_y, maze):
                enemy.state = "chase"
                enemy.start_searching(player_tile_x, player_tile_y, maze)
            else:
                if enemy.state == "chase":
                    enemy.state = "search"
                    if enemy.last_seen is None:
                        enemy.start_searching(player_tile_x, player_tile_y, maze)

            # state behavior
            if enemy.state == "wander":
                enemy.wander(dt_seconds, maze)
            elif enemy.state == "chase":
                # compute player velocity in tiles/sec for predictive aim
                pvel_tiles_per_s = (player_vx * FPS, player_vy * FPS)
                enemy.chase((player_tile_x, player_tile_y), pvel_tiles_per_s, maze, dt_seconds)
            elif enemy.state == "search":
                enemy.search_behavior(dt_seconds, maze)

            # wall avoidance steering before moving
            steer_away_from_walls(enemy, maze)

            # anti-stuck check
            enemy.anti_stuck(dt_seconds)

            # move + collision
            move_entity_with_collision(enemy, maze)

            # catching check
            if enemy.tile_pos() == (player_tile_x, player_tile_y):
                print("You were caught by an enemy. Game over.")
                running = False

        # exit check
        if (player_tile_x, player_tile_y) == exit_tile:
            print("You found the exit. You win!")
            running = False

        # camera center
        screen_rect = screen.get_rect()
        cur_w, cur_h = screen_rect.width, screen_rect.height
        player_px = player_x * TILE
        player_py = player_y * TILE
        cam_x = player_px - cur_w // 2
        cam_y = player_py - cur_h // 2
        world_w = S * TILE; world_h = S * TILE
        cam_x = max(0, min(cam_x, world_w - cur_w))
        cam_y = max(0, min(cam_y, world_h - cur_h))

        # draw
        screen.fill(COLOR_DARK)
        left = max(0, int(cam_x // TILE) - 1)
        right = min(S-1, int((cam_x + cur_w)//TILE) + 1)
        top = max(0, int(cam_y // TILE) - 1)
        bottom = min(S-1, int((cam_y + cur_h)//TILE) + 1)
        for ty in range(top, bottom+1):
            for tx in range(left, right+1):
                sx = tx * TILE - cam_x
                sy = ty * TILE - cam_y
                rect = pygame.Rect(int(sx), int(sy), TILE, TILE)
                if (tx, ty) in vis_tiles:
                    if maze[ty][tx] == 1:
                        pygame.draw.rect(screen, COLOR_SEEN_WALL, rect)
                    else:
                        pygame.draw.rect(screen, COLOR_SEEN_FLOOR, rect)
                else:
                    pygame.draw.rect(screen, COLOR_DARK, rect)

        # exit draw if visible
        ex, ey = exit_tile
        if (ex, ey) in vis_tiles:
            sx, sy = world_to_screen(ex, ey, cam_x, cam_y)
            pygame.draw.rect(screen, COLOR_EXIT, (sx, sy, TILE, TILE))

        # draw enemies (only if visible)
        for enemy in enemies:
            etx, ety = enemy.tile_pos()
            if (etx, ety) in vis_tiles:
                sx, sy = world_to_screen(enemy.x - 0.5, enemy.y - 0.5, cam_x, cam_y)
                color = COLOR_FAST if isinstance(enemy, FastEnemy) else COLOR_BASIC
                pygame.draw.rect(screen, color, (int(sx), int(sy), TILE, TILE))
                # facing indicator
                cx = sx + TILE/2; cy = sy + TILE/2
                ex2 = cx + math.cos(enemy.dir) * (TILE//2)
                ey2 = cy + math.sin(enemy.dir) * (TILE//2)
                pygame.draw.line(screen, (0,0,0), (int(cx), int(cy)), (int(ex2), int(ey2)), 2)

        # draw player
        draw_px = player_x * TILE - cam_x
        draw_py = player_y * TILE - cam_y
        pygame.draw.rect(screen, COLOR_PLAYER, (int(draw_px), int(draw_py), TILE, TILE))

        # HUD
        info = f"S={S}  Enemies={len(enemies)} (basic={NUM_BASIC}, fast={NUM_FAST})  Light={LIGHT_RADIUS}  Rays={RAY_COUNT}"
        text = font.render(info, True, COLOR_HUD)
        screen.blit(text, (8, 8))

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()

